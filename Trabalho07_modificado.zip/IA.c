/**
 * Saulo Tadashi Iguei NºUsp 7573548
 *
 * DATA entrega limite: 08/12/15
 *
 * SCC0201_01 - ICC2 _ Prof. Moacir
 *
 * Trabalho 6: Xadrez - Parte 1 (Geração de movimentos)
 *
 * >>>>> Trabalho 7: Xadrez -Parte 2 (Implementação de jogabilidade)
 *
 * >>>>> >>>>> Trabalho 8: Xadrez - Parte 3 (Implementação de Inteligência Articial)
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include "objeto.h"
#include "integration.h"
#include "peca.h"
#include "FEN.h"
#include "regra.h"
#include "IA.h"

//função calcula métrica de decisão da jogada
double metric (OBJETO **const collection, int pieces_num, MOV_PARAM)
{
	double best = 0.0;

	//TODO obs.: a única preocupação é com o roque do rei, que não é um campo de ataque dele, mas para a torre sim


	if(table != NULL && collection != NULL)
	{
		int i, j;

		//matriz de verificação, inicializado com Zeros
		int fields[TABLE_ROWS][TABLE_COLS];
		for(i = 0; i < TABLE_ROWS; i++)
			for(j = 0; j < TABLE_COLS; j++)
				fields[i][j] = 0;

		int denom = 0;
		int numer = 0;

		//verificar a lista de cada peça da rodada
		for(i = 0; i < pieces_num; i++)
		{
			OBJETO *obj = collection [i];
			white = getType(obj) - (getType(obj) >= 'a')*32;
			black = getType(obj) + (getType(obj) < 'a')*32;

			//pegar a lista de movimentos para a cada peça
			int size;
			char** list = (*getFunctionMov(obj))(MOV_VALUE);
		}

		if(denom)
			best = (double)numer / denom;
	}

	return best;
}
