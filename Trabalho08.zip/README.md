#SCC0201_01_Trabalho 8
_Pasta_para_trabalho 8_disciplina_de_ICC_2_

<span style="color:blue;">Pasta destinada para comportar trabalho 8 da disciplina usando uma IDE Eclipse, a priori.</span>

<b>HAMBIENTE:</b>

_UBUNTU 14.04 LTS - 64BITS_

_ECLIPSE - MARS_

_LINGUAGEM C (MAKEFILE)_
<div style="width:100%;height:auto">
	<img src="chess.jpeg" alt="chess Image" style="width:30%;height:auto;">

<p>
O trabalho consiste na continuação do trabalho 7 a cerca de partida de Xadrez. Na etapa anterior foi feita a elaboração do código para possibilitar a partida real em turno, com visualização do estado do tabuleiro pela notação FEN, utilizando o recurso de listagem de jogadas possíveis para cada peça no seu turno, sem que essa listagem seja impressa em tela. Com isso as jogadas requisitadas podem ser validadas segundo estas possibilidades.
</p>
<p>
No atual trabalho pede-se a implementação de uma Inteligencia Artificial que é capaz de realizar uma jogada contra o jogador segundo uma métrica estabelecida para cada situação. Também é pedido que se implemente uma nova condição de empate, Tripla Repetição, onde sua identificação deve ser feita por meio de tabela Hash.
</p>

</p>
